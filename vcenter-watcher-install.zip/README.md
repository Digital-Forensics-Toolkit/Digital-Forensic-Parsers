# vCenter Watcher — Install Package

## Contents
- `watcher.py` — the webhook listener + vCenter snapshot logic
- `vcenter-watcher.service` — systemd unit
- `install.sh` — automated installer (run as root)
- `test_webhook.sh` — sends a test-signed request to /trigger for manual verification
- `vcenter.pem` — (optional) place your vCenter CA cert here before installing if you want TLS verification; if absent, the installer will prompt for a path or fall back to the system trust store

## Install

```bash
sudo ./install.sh
```

You'll be prompted for:
- vCenter host
- vCenter username/password (for the service account you're using to authenticate)
- Target VM name (must match vCenter inventory exactly)
- CA cert path (skipped automatically if vcenter.pem is bundled in this folder)
- Listen port (default 8443)
- Whether to auto-generate a webhook shared secret (recommended — write down the value it prints)

The installer creates a dedicated `vwatcher` system user, sets up a venv at
`/opt/vcenter-watcher/venv`, installs `flask` + `pyvmomi`, writes `.env` with
your answers (permissions locked to 600), installs and starts the systemd
service.

## Verify

```bash
sudo systemctl status vcenter-watcher
curl http://127.0.0.1:8443/health
sudo journalctl -u vcenter-watcher -f
```

## Test end-to-end

Edit `test_webhook.sh` to use the webhook secret printed at the end of
install, then:

```bash
./test_webhook.sh
```

A 200 response with a snapshot result means it worked. Check vCenter's
Snapshot Manager for the VM to confirm.

## Notes

- The vCenter account used here should be scoped to the minimum privilege
  needed (VirtualMachine.State.CreateSnapshot) on just the target VM object,
  not a broad admin account, once you're past initial testing.
- Re-running `install.sh` is safe — it will overwrite `.env` with whatever
  you enter that run, so have your values ready.
