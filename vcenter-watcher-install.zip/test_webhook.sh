#!/bin/bash
#
# test_webhook.sh
# Simulates the victim VM's webhook call to listener.py for local testing.
# Must use the SAME secret as WEBHOOK_SECRET in your listener's environment,
# or the signature check will fail (403).

SECRET="a-long-random-test-secret"
URL="http://127.0.0.1:8443/trigger"
BODY='{"event":"dump_detected"}'

SIG=$(echo -n "$BODY" | openssl dgst -sha256 -hmac "$SECRET" | sed 's/^.* //')

curl -X POST "$URL" \
  -H "Content-Type: application/json" \
  -H "X-Signature: $SIG" \
  -d "$BODY"

echo ""
