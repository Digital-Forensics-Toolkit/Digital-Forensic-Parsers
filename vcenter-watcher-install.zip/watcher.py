"""
watcher.py

Webhook listener that triggers a vCenter memory snapshot when it receives
a validated request. Intended to run as a systemd service with config
supplied via an EnvironmentFile (.env).
"""

from flask import Flask, request, abort
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl, time, hmac, hashlib, os, json, datetime, logging

# ---------------------------------------------------------------------------
# Config (all supplied via environment / systemd EnvironmentFile)
# ---------------------------------------------------------------------------

WEBHOOK_SECRET = os.environ["WEBHOOK_SECRET"].encode()
VCENTER_HOST = os.environ["VCENTER_HOST"]
VCENTER_USER = os.environ["VCENTER_USER"]
VCENTER_PWD = os.environ["VCENTER_PWD"]
VM_NAME = os.environ["VM_NAME"]
CA_CERT_PATH = os.environ.get("CA_CERT_PATH")
OUTPUT_DIR = os.environ.get("OUTPUT_DIR", "/opt/vcenter-watcher/output")
LISTEN_PORT = int(os.environ.get("LISTEN_PORT", "8443"))

os.makedirs(OUTPUT_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)
log = logging.getLogger("watcher")

# ---------------------------------------------------------------------------
# vCenter helpers
# ---------------------------------------------------------------------------

def connect_vcenter():
    ctx = ssl.create_default_context(cafile=CA_CERT_PATH) if CA_CERT_PATH else None
    return SmartConnect(host=VCENTER_HOST, user=VCENTER_USER, pwd=VCENTER_PWD, sslContext=ctx)


def find_vm(si, vm_name):
    content = si.RetrieveContent()
    container = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.VirtualMachine], True
    )
    vm = next((v for v in container.view if v.name == vm_name), None)
    if not vm:
        raise RuntimeError(f"VM '{vm_name}' not found")
    return vm


def get_vm_info(si, vm_name):
    vm = find_vm(si, vm_name)
    summary = vm.summary
    config = vm.config
    hw = summary.config
    return {
        "name": vm.name,
        "power_state": summary.runtime.powerState,
        "guest_os": hw.guestFullName,
        "num_cpu": hw.numCpu,
        "memory_mb": hw.memorySizeMB,
        "num_disks": len([d for d in config.hardware.device if isinstance(d, vim.vm.device.VirtualDisk)]),
        "vmx_path": config.files.vmPathName,
        "tools_status": summary.guest.toolsStatus if summary.guest else None,
        "ip_address": summary.guest.ipAddress if summary.guest else None,
        "host": vm.runtime.host.name if vm.runtime.host else None,
    }


def snapshot_vm(si, vm_name, snapshot_name, description="Auto-snapshot triggered by watcher"):
    vm = find_vm(si, vm_name)

    task = vm.CreateSnapshot_Task(
        name=snapshot_name,
        description=description,
        memory=True,
        quiesce=False
    )

    while task.info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
        time.sleep(1)

    if task.info.state == vim.TaskInfo.State.error:
        raise RuntimeError(f"Snapshot task failed: {task.info.error.msg}")

    return {
        "vm": vm.name,
        "snapshot_name": snapshot_name,
        "state": str(task.info.state),
        "start_time": str(task.info.startTime),
        "completion_time": str(task.info.completeTime),
        "moref": str(task.info.result) if task.info.result else None,
    }

# ---------------------------------------------------------------------------
# Flask app
# ---------------------------------------------------------------------------

app = Flask(__name__)


@app.route("/trigger", methods=["POST"])
def trigger():
    signature = request.headers.get("X-Signature", "")
    expected = hmac.new(WEBHOOK_SECRET, request.data, hashlib.sha256).hexdigest()

    if not hmac.compare_digest(signature, expected):
        log.warning("Rejected webhook: invalid signature from %s", request.remote_addr)
        abort(403)

    log.info("Valid webhook received from %s, triggering snapshot", request.remote_addr)

    timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    snap_name = f"watcher-triggered-{timestamp}"

    try:
        si = connect_vcenter()
        result = snapshot_vm(si, VM_NAME, snapshot_name=snap_name)
        Disconnect(si)
    except Exception as e:
        log.error("Snapshot failed: %s", e)
        return {"status": "error", "detail": str(e)}, 500

    out_path = os.path.join(OUTPUT_DIR, f"snapshot_result_{timestamp}.json")
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

    log.info("Snapshot complete, wrote result to %s", out_path)
    return {"status": "ok", "file": out_path, "snapshot": result}, 200


@app.route("/health", methods=["GET"])
def health():
    return {"status": "ok"}, 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=LISTEN_PORT)
